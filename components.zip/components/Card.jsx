import React from 'react'
import banhuotimg from '../img/image 4.png'
const Card = () => {
  return (
    <div className="flex flex-col items-center ">
    <img src={banhuotimg} alt="img" className="w-80" />
    <div className="text-red-700 text-2xl font-bold mt-2">34.000 VNĐ</div>
    <div className="text-green-600 text-xl font-semibold mt-2">BÁNH ƯỚT (KHÔNG NHÂN)</div>
    <div className="text-gray-500 mt-2">Steam Rice-Paper (No Filling)</div>
  </div>
  )
}

export default Card