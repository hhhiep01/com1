import React from 'react'

const TabButtons = ({children}) => {
  return (
    <button type="button" className=" text-2xl border-teal-500 border-2 rounded-full w-48 h-12 text-green-600  font-medium hover:bg-green-700 hover:text-white">{children}</button>
  )
}

export default TabButtons