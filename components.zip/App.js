import logoBanhCuon from "./img/LOGO BÁNH CUỐN 2.png";
import banhuotimg from "./img/image 4.png";
import Card from "./components/Card";
import TabButtons from "./components/TabButtons";

function App() {
  return (
    <div className="App ">
      <div className="text-center font-bold text-green-600 text-2xl">
        THỰC ĐƠN
      </div>
      <div className="flex flex-row items-center justify-around mt-10 p-10">
        <TabButtons>TẤT CẢ</TabButtons>
        <TabButtons>BÁNH MẶN</TabButtons>
        <TabButtons>BÁNH CHAY</TabButtons>
      </div>
      <div className="flex flex-row justify-around p-16 flex-wrap lg:gap-3">
        <Card />
        <Card />
        <Card />



      </div>



    </div >
  );
}

export default App;
